'''
Problem Statement:Write a Program in Python to generate pseudo random numbers.
'''