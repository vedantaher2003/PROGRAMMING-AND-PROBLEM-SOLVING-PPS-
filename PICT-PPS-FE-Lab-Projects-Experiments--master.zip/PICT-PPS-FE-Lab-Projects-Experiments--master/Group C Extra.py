file=open("input.txt","w")
