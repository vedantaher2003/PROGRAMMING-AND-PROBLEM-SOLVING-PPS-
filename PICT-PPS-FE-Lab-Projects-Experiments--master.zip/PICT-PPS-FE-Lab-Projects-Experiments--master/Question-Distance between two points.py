x1=float(input('Enter x1:'))
y1=float(input('Enter y1:'))
x2=float(input('Enter x2:'))
y2=float(input('Enter y2:'))
d1=(x1-x2)**2+(y1-y2)**2
d=d1**0.5
print('Distance is:'+str(d))